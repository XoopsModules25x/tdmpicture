<html>
<head>
<title>PHP Thumbnailer Demo</title>
</head>
<body>
<img src="show_image.php?filename=sample.jpg&width=250&height=250" />
</body>
</html>